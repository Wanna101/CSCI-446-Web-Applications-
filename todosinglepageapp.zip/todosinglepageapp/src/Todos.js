import {useState, useEffect} from 'react';
import {Link} from 'react-router-dom';
import './Todos.css';

export default function Todos() {
	const [todos, setTodos] = useState([]);
	
	console.log("DID NOT CALL");
	useEffect(() => {
	 fetch(`http://localhost:4000/todos/todo`)
		.then((response) => response.json())
		.then((json) => setTodos(json.todos));
	}, []);

	return (
		<>
		{todos.map((todo) => (
			<div key={todo.id}>
            <Link to={`${todo.id}`}>
            <h5>{todo.title}</h5></Link>
			</div>
		))}
		</>
	);
}
