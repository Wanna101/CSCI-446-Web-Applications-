import {useState, useEffect} from "react";
import {Link, useParams} from "react-router-dom";
import React from "react";
import cors from "cors";

export default function NewTodo() {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [completed, setCompleted] = useState('');

	function handleSubmit(event) {
	  event.preventDefault();
      var item = {"title": title, "description": description, "completed": completed === 'true'};
	  fetch('http://localhost:4000/todos/todo', {
		   method: 'POST',
           body: JSON.stringify(item),
           mode: 'cors',
		   headers: {'Content-Type':'application/json'}
	  });
	  console.log("YEP");
	  console.log("title: " + title);
      console.log("description: " + description);
      console.log("status: " + completed);
 	};

    return (
    <>
      <div id="sidebar">
        <h1>New Todo</h1>
        <div>
          <form onSubmit={handleSubmit} method="post">
            Title: <input id="Title" placeholder="Title" onChange={(event) => setTitle(event.target.value)} value={title} /><br/>
            Description: <input id="Description" placeholder="Description" onChange={(event) => setDescription(event.target.value)} value={description} /><br/>
            Status: <input id="Status" placeholder="Status" onChange={(event) => setCompleted(event.target.value)} value={completed} /><br/>
			<br/>
            <button type="submit">New Todo</button>
          </form>
        </div>
      </div>
    </>
    );
}
	  {/*fetch('/', {
	   method: 'post',
	   headers: {'Content-Type':'application/json'},
	   body: {
		"first_name": this.firstName.value
	   }
	  });*/}
