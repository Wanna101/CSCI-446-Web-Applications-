import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Wrapper from './Wrapper';
import Todos from './Todos';
import SingleTodo from './SingleTodo';
import NewTodo from './NewTodo';
import './App.css';

function App() {
  return (
    <BrowserRouter>
	  <Routes>
	     <Route path ="/" element={<Wrapper />}>
	     	<Route path="/todo" element={<Todos />} />
	  	    <Route path="/todo/:todoId" element={<SingleTodo />} />
	  	    <Route path="/todo/new" element={<NewTodo />} />
	     </Route>
	  </Routes>
    </BrowserRouter>
  );
}

export default App;
