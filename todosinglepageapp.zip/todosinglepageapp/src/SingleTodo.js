import {useState,useEffect} from "react";
import {useParams} from "react-router-dom";

export default function SingleTodo() {
	const {todoId} = useParams();
	const [todo, setTodo] = useState({});

	useEffect(() => {
	fetch(`http://localhost:4000/todos/${todoId}`)
		.then((response) => response.json())
		.then((json) => setTodo(json));
	}, [todoId]);

	return (
		<div key={todo.id}>
        <h5>{todo.title}</h5>
		<p>Todo Description: {todo.description}</p>
		<p>Todo Status: {todo.completed ? "true" : "false"}</p>
		</div>
	);
}
