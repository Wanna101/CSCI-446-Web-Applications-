import { useAuth } from './auth/Authentication.js';
import { useState } from "react";
import { useNavigate } from 'react-router-dom';




export default function Logout() {
    const { user } = useAuth();

    if (user != null) {
        return <h1>{user}</h1>;
      }
      else{
        
        return (
            <>
            <br></br>
             <h3>Please log in to view this page.</h3>

            </>
        )
      }

    return <h1>Profile</h1>
}