import React, { useContext, useState } from 'react';

const AuthContext = React.createContext(null);

export default function Authentication({ children }) {
  let [user, setUser] = useState(null);

  const signin = async (username, password, callback) => {
    console.log(username + " " + password);
    try {
    fetch("http://localhost:3001/users/login?name=" + username + "&password=" + password, {
        method: 'POST',
        headers: {
            "Content-Type": "application/json",
            },
        credentials: 'include',
    }).then((response) => response.json())
    .then((json) => {
      console.log("user: " + json._id);
      setUser(json);

    });

    //if (response.status === 200){
    //}
    //else{
        //setInvalidText("Your username or password is incorrect.");
    //}


    } catch (e) {
      console.error(e);
    }
    callback();
  };

  const signout = async (callback) => {
    try {
      await signoutRequest();
      setUser(null);
    } catch (e) {
      console.error(e);
    }
    callback();
  };

  const refresh = async() => {
    // only refresh if the user is null
    if (user) {
      return;
    }

    try {
      const user = await meRequest();
      setUser(user);
      return true;
    } catch (e) {
      setUser(null);
    }
    return false;
  }

  const value = { user, signin, signout, refresh };

  return (
    <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
  );
  
}

export function useAuth() {
  if (AuthContext !== null) {
    return useContext(AuthContext);
  }
  throw Error('');
}


  
  export async function signoutRequest() {
    const response = await fetch('http://localhost:3001/logout', {
      method: 'POST',
      credentials: 'include',
    });
  
    if (response.status !== 200) {
      const json = await response.json();
      throw Error(json.message);
    }
  
    return;
  }
  
  export async function meRequest() {
    const response = await fetch('http://localhost:3001/users/authenticate', {
      credentials: 'include',
    });
  
    const json = await response.json();
  
    if (response.status !== 200) {
      throw Error(json.message);
    }
  
    return json;
  }
  