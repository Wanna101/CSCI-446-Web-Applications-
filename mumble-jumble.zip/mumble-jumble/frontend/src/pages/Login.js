import { useState } from "react";
import {Link, useParams} from "react-router-dom"
import { useAuth } from './auth/Authentication.js';

export default function Login() {

    //const [username, setUsername] = useState("");
    //const [password, setPassword] = useState("");

    const [invalidText, setInvalidText] = useState("");

    const { user, signin, refresh } = useAuth();

    /*
    const refreshSync = useCallback(() => {
        async function refreshSync() {
          return await refresh();
        };
        return refreshSync();
      }, [refresh]);
    
      const refreshed = refreshSync();
      */

    if (user && invalidText == "") {
        setInvalidText("You are now logged in. If you refresh this page, you will be logged out.");
      }

    //async function changeUsername (event) {
    //    setUsername(this)
   // }

    //async function changePassword  (event)  {
    //    setPassword(this)
    //}

    const handleSubmit = async (event) => {
        event.preventDefault();
        const form = new FormData(event.currentTarget);
        const username = form.get('username');
        const password = form.get('password');

        await signin( username, password, () => {
            //navigate(redirect, { replace: true });
          });
      

        /*
    
        let formData = new FormData(e.currentTarget);
        let username = formData.get('username');
        let password = formData.get('password');
    
        await signin({ username, password }, () => {
          navigate(redirect, { replace: true });
        });
        */
      };

    return (
    <>
    <h1>Login</h1>
    <form onSubmit={handleSubmit}>
      <label htmlFor="username">Username: </label>
      <input type="text" name="username"/>
      <br></br>
      <label htmlFor="password">Password: </label>
      <input type="password" name="password"/>
      <br></br>
      <br></br>
      <button type="submit">Sign In</button>
      <br></br>
      <br></br>
      <p>{invalidText}</p>
    </form>
    </>
  );
}