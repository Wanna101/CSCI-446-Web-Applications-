import { useAuth } from './auth/Authentication.js';
import React, {useState} from 'react';

export default function CreateAccount() {
    const { user } = useAuth();
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

  // Handle form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    // Do something with the form data
  };
    
    const handleSubmit = async (event) => {
        event.preventDefault();
        const form = new FormData(event.currentTarget);
        const username = form.get('username');
        const password = form.get('password');

        await signin( username, password, () => {
          });
      

        
      };

    return (
        <>
    <h1>Create Account</h1>
    <form onSubmit={handleSubmit}>
      <label htmlFor="username">Username: </label>
      <input type="text" name="username" value={username} onChange={(e) => setUsername(e.target.value)}/>
      <br></br>
      <label htmlFor="password">Password: </label>
      <input type="password" name="password" value={password} onChange={(e) => setPassword(e.target.value)}/>
      <br></br>
      <br></br>
      <button type="submit"></button>
      <br></br>
      <br></br>
      <p>{invalidText}</p>
    </form>
    </>
);
}
