import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useAuth } from './auth/Authentication.js';

//import "../Form.css";

export default function Profile() {
    //const [user, setUser] = useState([]);

        const { user } = useAuth();
        const [posts, setPosts] = useState([]);

        //BROKEN!!!!!
        /*
        if (user != null){
            useEffect(() => {
                fetch("http://localhost:3001/users/" + user._id + "/posts")
                .then((body) => body.json())
                .then((json) => {
                    if (json.status != 404){
                        setPosts(() => [...json]);
                    }
                    else{
                        setPosts(null);
                    }
                })
            });
            
            
                return (
                    <>
                    <form class="frontpage">
                    <div class="form_title">Posts For {user.name}</div>
                    </form><hr/>
                    <form class="frontpage">
                        <ul>
                        {posts.map((post) => (
                            <div key={post._id}>
                               <p>{post.text}</p> 
                            </div>
                        ))}
                        </ul>
                    </form>
                    </>
                    );
            }
            */
            return (
                <>
                <br></br>
                <h2>Please log in to view this page.</h2>
                </>
            )



    /*
    useEffect(() => {
        fetch(`http://localhost:3001/users/${user_id}`)
            .then((response) => response.json())
            .then((json) => setUser(json)); 
    }, [user_id]);
    
    if (user != null){
        return (
            <div class="frontpage" key={user._id}>
            <div class="form_title"><h1>User {user.name}</h1></div><br/>
                <Link to={`/users/${user._id}/posts`}>Posts</Link>
        </div>
        );
    }
    return (
        <>
        <br></br>
        <h2>Please log in to view this page.</h2>
        </>
    )
    */
    
    

}
