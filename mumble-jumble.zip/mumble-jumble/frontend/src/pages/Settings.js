import { useAuth } from './auth/Authentication.js';
import {useState} from "react";
import React, {Component} from "react";

export default function Settings() {

    const { user } = useAuth();
    const [data, setData] = useState("");

    const deleteAccount = () => {
	    fetch(`http://localhost:3001/users/` , {
	    	method: "DELETE",
		body: "",
		mode: "cors",
		headers: {
			"Content-Type": "application/json",
		},
	    })
    };

    async function handleChange(event) {
	    setData(event.target.value);
    }

    const handleSubmit = (event) => {
	    event.preventDefault()
	    console.log(data)
	    deleteAccount()
    };

    return (
	    <>
	    <form onSubmit={handleSubmit}></form>
        </>
    )
}