import { useEffect, useState } from "react";
import { useAuth } from './auth/Authentication.js';

import "../styles.css"

export default function Jumble() {
    const [posts, setPosts] = useState([]);
    const { user } = useAuth();

    useEffect(() => {
        fetch(`http://localhost:3001/`)
        .then((response) => response.json())
            .then((json) => {
                if (json.status !== 404) {
                    setPosts(() => [...json]);
                }
                else{
                    setPosts(null);
                }
            });
    }, [])

    return (
        <>
            <h1>Jumble</h1>

            {posts.map((post) => (
                <div className='post'>
                    <span>{post.scramble_text}</span>
                    <div className="post-footer">
                        <small>{post.user_id}</small>
                    </div>
                </div>
            ))}
        </>
    );
}