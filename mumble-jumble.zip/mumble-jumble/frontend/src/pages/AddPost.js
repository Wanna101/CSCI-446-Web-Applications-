import { useAuth } from './auth/Authentication.js';
import { useState } from "react";
import { Link } from "react-router-dom"



export default function AddPost() {

    const { user } = useAuth();

    const [text, setText] = useState("")

    if (user != null){

        const sendPost = () => {
            fetch("http://localhost:3001/users/" + user._id + "/posts?text=" + text, {
               method: "POST",
               body: "",
               mode: "cors",
               headers: {
                 "Content-Type": "application/json",
               },
             })
        };
    
        async function handleChange(event){
            setText( event.target.value);
        };
    
        const handleSubmit = (event) => {
            event.preventDefault()
            sendPost()
    
        };
    
        return (
            <>
                <h1>Add Post</h1>
                <form onSubmit={handleSubmit}>
                    <div className="form_title">Add Post</div>
                    <div>
                    <label htmlFor='name'><b>Post: </b><br/></label>
                    <input className="form_input"
                        type = 'text' 
                        name='name'
                        placeholder='Enter Post (Text)'
                        value = {text}
                        onChange = {handleChange}
                    />
                    </div>
               
                    <div>
                    <button>Create Post</button>
                    </div>
                </form><br/>
                <Link className="link" to={`/`}>Back to Jumble Home Page</Link>
            </>
    
        );
    }

    return (
        <>
        <br></br>
        <h2>Please log in to view this page.</h2>
        </>
    )

}