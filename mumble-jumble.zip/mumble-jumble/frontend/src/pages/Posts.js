import { useAuth } from './auth/Authentication.js';
import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
//import '../Form.css';

export default function Items(){
    const [posts, setPosts] = useState([]);
    //const [user, setUser] = useState({});

        const { user } = useAuth();

    /*
    useEffect(() => {
        fetch(`http://localhost:3001/users/${user_id}`)
            .then((response) => response.json())
            .then((json) => {
                if (json.status != 404){
                    setUser(json);
                }
                else{
                    setUser(null)
                }
            });
    }, [user_id]);
    */
    if (user != null){
    useEffect(() => {
        fetch("http://localhost:3001/users/" + user._id + "/posts")
        .then((body) => body.json())
        .then((json) => {
            if (json.status != 404){
                setPosts(() => [...json]);
            }
            else{
                setPosts(null);
            }
        })
    }, [user_id]);
    
    
        return (
            <>
            <form class="frontpage">
            <div class="form_title">Posts For {user.name}</div>
            </form><hr/>
            <form class="frontpage">
                <ul>
                {posts.map((post) => (
                    <div key={post._id}>
                       <p>{post.text}</p> 
                    </div>
                ))}
                </ul>
            </form>
            </>
            );
    }
    return (
        <>
        <br></br>
        <h2>Please log in to view this page.</h2>
        </>
    )
    
    
    
}
