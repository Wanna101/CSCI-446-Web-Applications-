import { Link } from "react-router-dom"
import { useAuth}  from './pages/auth/Authentication.js';


export default function Navbar() {

    const { user } = useAuth();

    if (user != null){
        return <nav className="nav">
        <Link to="/" className="site-title">Mumble Jumble</Link>
        <ul>
            <li>
                <Link to="/">Jumble</Link>
            </li>
            <li>
                <Link to="/profile">Profile</Link>
            </li>
            <li>
                <Link to="/addpost">Post Mumble</Link>
            </li>
            <li>
                <Link to="/settings">Settings</Link>
            </li>
            <li>
                <Link to="/logout">Logout</Link>
            </li>
            <li>
                <Link to="/create-account">Create Account</Link>
            </li>
        </ul>
    </nav>
    }
    return <nav className="nav">
        <Link to="/" className="site-title">Mumble Jumble</Link>
        <ul>
            <li>
                <Link to="/">Jumble</Link>
            </li>
            <li>
                <Link to="/profile">Profile</Link>
            </li>
            <li>
                <Link to="/addpost">Post Mumble</Link>
            </li>
            <li>
                <Link to="/settings">Settings</Link>
            </li>
            <li>
                <Link to="/login">Login</Link>
            </li>
            <li>
                <Link to="/create-account">Create Account</Link>
            </li>
        </ul>
    </nav>
}


