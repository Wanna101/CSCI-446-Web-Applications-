import React from 'react';
import { Routes, Route } from 'react-router-dom';
import './App.css';
import Navbar from './Navbar';
import Jumble from './pages/Jumble.js';
import Profile from './pages/Profile.js';
import AddPost from './pages/AddPost.js';
import Settings from './pages/Settings.js';
import Login from './pages/Login.js';
import Logout from './pages/Logout.js';
import CreateAccount from './pages/CreateAccount';
import Authentication from './pages/auth/Authentication.js';


function App() {
  


  return (
    <>
      <Authentication>
      <Navbar />
      <div className='container'>
        <Routes>
          <Route path="/" element={<Jumble />}/>
          <Route path="/profile" element={<Profile />}/>
          <Route path="/addpost" element={<AddPost />}/>
          <Route path="/settings" element={<Settings />}/>
          <Route path="/login" element={<Login />}/>
          <Route path="/logout" element={<Logout />}/>
          <Route path="/create-account" element={<CreateAccount />}/>
        </Routes>
      </div>
      </Authentication>
    </>
      
  );
}

export default App;
