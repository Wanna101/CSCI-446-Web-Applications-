import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import bcrypt from 'bcrypt';
import cookieParser from 'cookie-parser';
import MongoClient from 'mongodb';
import { v4 as uuidv4 } from 'uuid';

const port = 3001;

const usersRouter = express.Router();
const postsRouter = express.Router();
const rootRouter = express.Router();

const cookieSchema = mongoose.Schema({
  _id: mongoose.SchemaTypes.ObjectId,
  name: mongoose.SchemaTypes.String
}, {versionKey: false})
const MongoCookies = mongoose.model('cookies', cookieSchema)

const userAuthSchema = mongoose.Schema({
  _id: mongoose.SchemaTypes.ObjectId,
  name: mongoose.SchemaTypes.String,
  password: mongoose.SchemaTypes.String
}, {versionKey: false})
const MongoUserAuth = mongoose.model('userAuth', userAuthSchema);

const usersSchema = mongoose.Schema({
  _id: mongoose.SchemaTypes.ObjectId,
  name: mongoose.SchemaTypes.String,
  picture_id: mongoose.SchemaTypes.String,
  following_list: mongoose.SchemaTypes.Array
}, {versionKey: false})
const MongoUser = mongoose.model('users', usersSchema);

const postSchema = mongoose.Schema({
  _id: mongoose.SchemaTypes.ObjectId,
  text: mongoose.SchemaTypes.String,
  scramble_text: mongoose.SchemaTypes.String,
  user_id: mongoose.SchemaTypes.ObjectId,
  user_name: mongoose.SchemaTypes.String
}, {versionKey: false});
const MongoPost = mongoose.model('posts', postSchema);

// ----
// USER 
// ----

//
//  Creating a new user
//
usersRouter.post('/newuser', async (req, res) => {
  const existingUser = await MongoUser.findOne({name: req.query.name});
  if (existingUser != null){
    res.status(500);
    res.json( {status: 500, message: 'this username is taken.'} );
  }
  else{
    console.log(req.body);
    const newUserAuth = req.body;
    newUserAuth._id = new mongoose.Types.ObjectId();
    newUserAuth.name = req.query.name;
    newUserAuth.password = await bcrypt.hash(req.query.password, 10);

    const newUser = req.body;
    newUser._id = newUserAuth._id;
    newUser.name = newUserAuth.name;

    try {
      const result1 = await new MongoUserAuth(newUserAuth).save();
      const result2 = await new MongoUser(newUser).save();
      console.log(result2);
      res.status(201);
      res.json( newUser );
    }
    catch (e){
      console.log(e);
      res.status(500);
      res.json( {status: 500, message: "error creating new user"} );
    }
  }
})

//
// Logging in with username and password. This gives the user a cookie on success, and saves that cookie to the database.
//
usersRouter.post('/login', async (req, res) => {
  const name = req.query.name;
  //const password = await bcrypt.hash(req.query.password, 10);
  const password = req.query.password;
  console.log(name);
  console.log(password);

  try {
    const user = await MongoUserAuth.findOne({name: name});
    if (user.name != null){
      console.log(user.name);
      console.log(user.passsword);
      const match = await bcrypt.compare(password, user.password);
      if (match){
        const token = new mongoose.Types.ObjectId();
        const newCookie = req.body;
        newCookie._id = token;
        newCookie.name = user.name;
        try {
          const result = await new MongoCookies(newCookie).save();
          const user2 = await MongoUser.findOne({name: name});
          console.log(user);
          res.status(200)
          res.cookie("token", token, {
              httpOnly: false,
              sameSite: "lax",
              maxAge: 2147483646});
          res.json(user2);
          return;
  
        } catch(e){
          console.log(e);
          res.status(404);
          res.json( {status: 404, message: "error logging in."} );
        }
      }
    }
    res.status(400);
    res.json( {status: 400, message: "this username or password is incorrect." } );
  }
  catch (e) {
    console.log(e);
    res.status(404);
    res.json( {status: 404, message: "error logging in."} );
  }
})

//
// Deleting the cookie in the database and from the user's computer.
//
usersRouter.post("/logout", async (req, res) => {
  try {
    await MongoCookies.deleteMany({ name: req.query.name })
    res.status(200);
    res.clearCookie("token")
    res.end();  
  } catch (e){
    res.status(500);
    res.json(e);
    res.end();  
  }
})

//
// Checking if the user's cookie is valid (token exists, and name matches)
//
usersRouter.get("/authenticate", async (req, res) => {
  const token = req.cookies.token;
  const cookie = await MongoCookies.findOne({_id: token}) 
  
  if (cookie._id != null && cookie.name == req.query.name){
    res.status(200);
    res.cookie("token", cookie, {
      httpOnly: false,
      sameSite: "lax",
      maxAge: 86400 * 1000});
    res.json( "successfully authenticated" );
    res.end();
    return;
  }
  res.status(400);
  res.json( {message: "user could not be authenticated"} );
  res.end();
})

//
//  TODO: (do we actually need this??)
//
usersRouter.put('/password', async (req, res) => {
	const id = req.params.user_id;
	try {
		const password = await MongoUserAuth.find({user_id: id});
		const requestBody = req.body;
		requestBody._id = id;
		requestBody.name = req.params.description;
		console.log(req.params);
    } catch (e){

    }
})

//
// POSTS
//
postsRouter.get('/', async (req, res) => {
    const id = req.params.user_id;
  try {
    const posts = await MongoPost.find({user_id: id});
    if (posts.length == 0){
      res.status(404);
      res.json({ status: 404, message: 'no posts were found in this user.'});
      return;
    }
    console.log(posts);
    res.status(201);
    res.send(posts);
  }
  catch (e) {
    console.log(e);
    res.status(404);
    res.json( {status: 404, message: e} );
  }
})

postsRouter.get('/:post_id', async (req, res) => {
  const u_id = req.params.user_id;
  const id = req.params.post_id;
  try {
    const post = await MongoPost.findOne({_id: id, user_id: u_id});
    console.log(post);
    if (post === null){
      res.status(404);
      res.send({ status: 404, message: 'a post with that id was not found.'});
      return;
    }
    res.send(post);
  }
  catch(e) {
    console.log(e);
    res.status(500);
    res.json( {status: 500, message: e} );
  }
})

postsRouter.post('/', async (req, res) => {
  const newPost = req.body;
  newPost._id = new mongoose.Types.ObjectId();
  newPost.user_id = req.params.user_id;
  newPost.text = req.query.text;
  newPost.scramble_text = scrambleText(req.query.text)
  newPost.user_name = await MongoPost.findOne({_id: newPost.user_id}).name
  console.log(req.params);
  try {
    const result = await new MongoPost(newPost).save();
    console.log(result);
    res.status(201);
    res.json( {status: 201, message: 'new post added'} )
  }
  catch (e){
    console.log(e);
    res.status(500);
    res.json( {status: 500, message: e} );
  }
})

//
// ROOT
//

rootRouter.get('/', async(req, res) => {
	const posts = await MongoPost.find();

	res.send(posts);
})

await mongoose.connect('mongodb://127.0.0.1:27017/spa-db');


const app = express();
app.use(cors({origin: "http://localhost:3000", credentials: true}));
app.use(express.json());
app.use(cookieParser());


postsRouter.mergeParams = true;
usersRouter.use('/:user_id/posts', postsRouter);
app.use('/', rootRouter);
rootRouter.use('/users', usersRouter);


app.listen(port, () => {
  console.log(`listening on port ${port}`)
})


function scramble(line) {
  line = line.split("");
  for(var b = line.length - 1; 0 < b; b--) {
    var c = Math.floor(Math.random()*(b+1));
    var d = line[b];
    line[b] = line[c];
    line[c] = d
  }
  return line.join("")
}

function scrambleText(text) {
  var lines = text.split('\n');
  for(var i = 0; i < lines.length; i++){
      lines[i] = scramble(lines[i]).split('').join(' ');
  }
  text = lines.join('\n');
  return text;
}